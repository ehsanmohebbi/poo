#include "controller.h"

void selectare(Film **vect, int len1, int id, Film **vect2, int &len2) {
	for (int i = 0; i < len1; i++)
		if (id == vect[i]->getid()) {
			vect2[len2] = vect[i];
			len2++;
		}
}