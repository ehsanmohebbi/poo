#include "test.h"
#include <iostream>
#include "repository.h"

using namespace std;

int main() {
	test();
	return 0;
}
