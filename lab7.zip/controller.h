#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "repository.h"

void selectare(Film **vect, int len1, int id, Film **vect2, int &len2);

#endif CONTROLLER_H
#pragma once

