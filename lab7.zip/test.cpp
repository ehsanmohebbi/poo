#include <assert.h>
#include "test.h"
#include "repository.h"
#include "controller.h"

void test() {

	//selectare
	Film **vect = new Film *[6];
	Film *fil1 = new Film;
	fil1->setid(1);
	Film *fil2 = new Film;
	fil2->setid(2);
	Film *fil3 = new Film;
	fil3->setid(3);
	Serial *ser1 = new Serial;
	ser1->setid(1);
	Serial *ser2 = new Serial;
	ser2->setid(2);
	Serial *ser3 = new Serial;
	ser3->setid(3);
	vect[0] = fil1;
	vect[1] = fil2;
	vect[2] = fil3;
	vect[3] = ser1;
	vect[4] = ser2;
	vect[5] = ser3;
	int len1 = 6;
	int len2 = 0;
	int id = 2;
	Film **vect2 = new Film *[6];
	selectare(vect, len1, id, vect2, len2);
	assert(len2 == 2);
	assert(vect2[0] == fil2);
	assert(vect2[1] == ser2);
	cout << "vector functioneaza" << endl;

	//constructorul implicit
	Film ifil;
	Serial iser;
	Episod iepis;
	assert(ifil.getid() == 0);
	assert(iser.getid() == 0);
	assert(iser.getnrEpisoade() == 0);
	assert(iepis.getDenumire() == NULL);
	assert(iepis.getDurata() == 0);
	cout << "implicit ok" << endl;

	//constructorul explicit
	int eid = 0;
	int edurata = 150;
	int enr = 7;
	char *edenumire;
	edenumire = new char[15];
	edenumire = "Fast & Forius7";
	Film efil(eid);
	Serial eser(eid, enr);
	Episod eepis(edenumire, edurata);
	assert(efil.getid() == 0);
	assert(eser.getid() == 0);
	assert(eser.getnrEpisoade() == 7);
	assert(eepis.getDurata() == 150);
	assert(strcmp(eepis.getDenumire(), "Fast & Forius7") == 0);
	cout << "explicit ok" << endl;

	//constructor de copiere
	Film cfil = efil;
	Serial cser = eser;
	Episod cepis = eepis;
	assert(cfil.getid() == 0);
	assert(cser.getid() == 0);
	assert(cser.getnrEpisoade() == 7);
	assert(cepis.getDurata() == 150);
	assert(strcmp(cepis.getDenumire(), "Fast & Forius7") == 0);
	cout << "copiere ok" << endl;

	//ofilrator de atribuire
	ifil = cfil;
	cout<<"11111111111111111111111"<<endl;
	iepis = cepis;
	cout<<"222222222222222222222222222"<<endl;
	iser = cser;
	cout<<"333\n";
	assert(ifil.getid() == 0);
	assert(iser.getid() == 0);
	assert(iser.getnrEpisoade() == 7);
	assert(iepis.getDurata() == 150);
	assert(strcmp(iepis.getDenumire(), "Fast & Forius7") == 0);
	cout << "atribuire ok" << endl;

	//set
	Film sfil;
	Serial sser;
	Episod sepis;
	sfil.setid(1);
	sser.setid(1);
	sser.setnrEpisoade(1);
	sepis.setDenumire("Fast & Forius7");
	sepis.setDurata(150);
	assert(sfil.getid() == 1);
	assert(sser.getid() == 1);
	assert(sser.getnrEpisoade() == 1);
	assert(sepis.getDurata() == 150);
	assert(strcmp(sepis.getDenumire(), "Fast & Forius7") == 0);
	cout << "set ok" << endl;

}