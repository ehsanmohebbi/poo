#ifndef REPOSITORY_H
#define REPOSITORY_H

#include <iostream>
#include <string.h>
#include <cstdlib>

using namespace std;

class Film {
protected:
	int id;
public:

	Film();

	Film(int f1);

	Film(const Film &f);

	~Film();

	Film &operator=(const Film &b);

	friend ostream &operator<<(ostream &os, const Film &p);

	void setid(int d);

	int getid();

	
};

class Episod{
private:
	char *denumire;
	int durata;

public:
	Episod();

	Episod(char *denumire, int p);

	Episod(const Episod &d);

	~Episod();

	Episod & operator = (const Episod &d);

	friend ostream &operator<<(ostream &os, const Episod &p);
	//get:
	char *getDenumire();
	int getDurata();

	//set:
	void setDenumire(char *d1);
	void setDurata(int p);

	

};



const int MAX_Episoade = 10;

class Serial:public Film {
private:
	int nrEpisoade;
	Episod *episoade;
public:
	Serial();

	Serial(int f1, int d2);

	Serial(const Serial &s);

	~Serial();

	Serial &operator=(const Serial &f);

	friend ostream &operator<<(ostream &os, const Serial &m);

	int getnrEpisoade();

	//Episod *getEpisoade();

	void setnrEpisoade(int n);

	//void setEpisoade(Episod *ep);
};



#endif //REPOSITORY_H