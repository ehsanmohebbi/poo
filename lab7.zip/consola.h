#ifndef CONSOLA_H
#define CONSOLA_H

int main();

#endif //CONSOLA_H
