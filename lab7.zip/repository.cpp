#include "repository.h"

using namespace std;

Film::Film() {
	id = 0;
}

Film::Film(int f1) {
	id = f1;
}

Film::Film(const Film &f) {
	this->id = f.id;
}

Film::~Film() {
}

Film &Film::operator=(const Film &b) {
	if (this != &b) {
		this->id = b.id;
	}
	return *this;
}

void Film::setid(int d) {
	id = d;
}

int Film::getid() {
	return id;
}

ostream &operator<<(ostream &os, const Film &p) {
	os << "Film" << endl << "id:" << p.id << endl << "--- --- ---" << endl;
	return os;
}



Serial::Serial() : Film() {
	
	nrEpisoade = 0;
	Episod *episoade = new Episod[MAX_Episoade];
	
}

Serial::Serial(int f1, int d2) : Film(f1) {
	nrEpisoade = d2;
		Episod *episoade = new Episod[MAX_Episoade];
	}

Serial::Serial(const Serial &d) : Film(d) {
	nrEpisoade = d.nrEpisoade;
		Episod *episoade = new Episod[MAX_Episoade];
		for (int i = 0; i < nrEpisoade;i++)
		{
			episoade[i]=d.episoade[i];
		}
}

Serial::~Serial() {
	delete[]episoade;
}

Serial &Serial::operator=(const Serial &d) {
	if (this != &d) {
		//Film::operator=(d);
		this->id = d.id;
		this->nrEpisoade = d.nrEpisoade;
		for (int i = 0; i < nrEpisoade;i++)
		{
			episoade[i]=d.episoade[i];
		}
	}
	return *this;
}

ostream &operator<<(ostream &os, const Serial &p) {
	os << "Serial" << endl << "id:" << p.id << endl << "nr Episoade:" << p.nrEpisoade << endl <<
		"--- --- ---" << endl;
	return os;
}
int Serial::getnrEpisoade()
{
	return nrEpisoade;
}
//Episod *getEpisoade()
//{
//	return episoade;
//}

void Serial::setnrEpisoade(int n) {
	nrEpisoade = n;
}
/*void setEpisoade(Episod *ep)
{
	episoade = ep;
}
*/

Episod::Episod() {
	denumire = NULL;
	durata = 0;
}

Episod::Episod(char *denumire, int p) {
	this->denumire = new char[strlen(denumire) + 1];
	strcpy(this->denumire, denumire);
	durata = p;
}

Episod::Episod(const Episod &f) {
	if(f.denumire!=NULL)
		{
			denumire = new char[strlen(f.denumire) + 1];
			strcpy(denumire, f.denumire);
		}
		else
			denumire=NULL;
	durata = f.durata;
}

Episod::~Episod() {
	if (denumire) {
		delete[] denumire;
		denumire = NULL;
	}
}

Episod &Episod::operator = (const Episod &f) {
	if (this != &f) {
		if (denumire)
			delete[] denumire;
		
		if(f.denumire != NULL){
			denumire = new char[strlen(f.denumire) + 1];
			strcpy(denumire, f.denumire);
			
		}
		else
			denumire = NULL;
		durata = f.durata;
	}
	return *this;
}

ostream &operator<<(ostream &os, const Episod &f) {
	//...............
	if(f.denumire != NULL)
		os << "Episod" << endl << "denumire:" << f.denumire << endl << "durata:" << f.durata << endl << "--- --- ---" << endl;
	
	return os;
}

//get:
char *Episod::getDenumire() {
	return denumire;
}

int Episod::getDurata() {
	return durata;
}

//set:

void Episod::setDenumire(char *d1) {
	if (denumire)
		delete[] denumire;
	denumire = new char[strlen(d1) + 1];
	strcpy(denumire, d1);
}

void Episod::setDurata(int p) {
	durata = p;
}


